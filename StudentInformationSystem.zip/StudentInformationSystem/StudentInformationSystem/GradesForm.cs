﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentInformationSystem
{
    public partial class GradesForm : Form
    {
        public GradesForm()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void GradesForm_Load(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add("CS 314", "Nelson Barnes", "B", "A");
            dataGridView1.Rows.Add("CS 488", "Venkata Atluri", "C", "B");
            dataGridView1.Rows.Add("CS 328", "Yujian Fu", "A", "A");
            dataGridView1.Rows.Add("CS 381", "Kylie Nash", "D", "A");

        }
    }
}

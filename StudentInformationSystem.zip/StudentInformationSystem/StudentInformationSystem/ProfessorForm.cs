﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace StudentInformationSystem
{
    public partial class ProfessorInfoForm : Form
    {
        public ProfessorInfoForm()
        {
            InitializeComponent();
            
        }

        private void ProfessorInfoForm_Load(object sender, EventArgs e)
        {

        }

        

        

        private void profFirstLBL_Click(object sender, EventArgs e)
        {

        }

        private void proFnameTXTBOX_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
             
            int rowIndex = e.RowIndex; 

            DataGridViewRow row = dataGridView.Rows[rowIndex];

            sIdTXTBOX.Text = row.Cells[0].Value.ToString();
            sFnameTXTBOX.Text = row.Cells[1].Value.ToString();
            sLnameTXTBOX.Text = row.Cells[2].Value.ToString();
            pgTXTBOX.Text = row.Cells[3].Value.ToString();
            midtermTXTBOX.Text = row.Cells[4].Value.ToString();
            finalTXTBOX.Text = row.Cells[5].Value.ToString();



            

        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            sFnameTXTBOX.Text = "";
            sLnameTXTBOX.Text = "";
            sIdTXTBOX.Text = "";
            pgTXTBOX.Text = "";
            midtermTXTBOX.Text = "";
            finalTXTBOX.Text = "";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void saveBTN_Click(object sender, EventArgs e)
        {
      
            string sIdTXTBOX = this.sIdTXTBOX.Text;
            string sFnameTXTBOX = this.sFnameTXTBOX.Text;
            string sLnameTXTBOX = this.sLnameTXTBOX.Text;
            string pgTXTBOX = this.pgTXTBOX.Text;
            string midtermTXTBOX = this.midtermTXTBOX.Text;
            string finalTXTBOX = this.finalTXTBOX.Text;

            dataGridView.Rows.Add(sIdTXTBOX, sFnameTXTBOX, sLnameTXTBOX, pgTXTBOX, midtermTXTBOX, finalTXTBOX);


            
          
           

            foreach (DataGridViewRow row in dataGridView.Rows)
                row.Cells["Average"].Value = (Convert.ToDouble(row.Cells[3].Value) + Convert.ToDouble(row.Cells[4].Value) + Convert.ToDouble(row.Cells[5].Value)) / 3;




        }

        private void deleteBTN_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView.CurrentCell.RowIndex;
            dataGridView.Rows.RemoveAt(rowIndex);

        }

        private void updateBTN_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView.CurrentCell.RowIndex;
            DataGridViewRow newDataRow = dataGridView.Rows[rowIndex];
            newDataRow.Cells[0].Value = sIdTXTBOX.Text;
            newDataRow.Cells[1].Value = sFnameTXTBOX.Text;
            newDataRow.Cells[2].Value = sLnameTXTBOX.Text;
            newDataRow.Cells[3].Value = pgTXTBOX.Text;
            newDataRow.Cells[4].Value = midtermTXTBOX.Text;
            newDataRow.Cells[5].Value = finalTXTBOX.Text;
      
             foreach (DataGridViewRow row in dataGridView.Rows)
                row.Cells["Average"].Value = (Convert.ToDouble(row.Cells[3].Value) + Convert.ToDouble(row.Cells[4].Value) + Convert.ToDouble(row.Cells[5].Value)) / 3;

        }
    }
}

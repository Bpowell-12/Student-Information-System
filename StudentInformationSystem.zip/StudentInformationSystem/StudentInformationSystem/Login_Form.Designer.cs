﻿namespace StudentInformationSystem
{
    partial class Login_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.usernameTXTBOX = new System.Windows.Forms.TextBox();
            this.passwordTXTBOX = new System.Windows.Forms.TextBox();
            this.passwordLBL = new System.Windows.Forms.Label();
            this.usernameLBL = new System.Windows.Forms.Label();
            this.loginBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // usernameTXTBOX
            // 
            this.usernameTXTBOX.Location = new System.Drawing.Point(120, 36);
            this.usernameTXTBOX.Name = "usernameTXTBOX";
            this.usernameTXTBOX.Size = new System.Drawing.Size(247, 20);
            this.usernameTXTBOX.TabIndex = 0;
            // 
            // passwordTXTBOX
            // 
            this.passwordTXTBOX.Location = new System.Drawing.Point(120, 91);
            this.passwordTXTBOX.Name = "passwordTXTBOX";
            this.passwordTXTBOX.Size = new System.Drawing.Size(247, 20);
            this.passwordTXTBOX.TabIndex = 1;
            // 
            // passwordLBL
            // 
            this.passwordLBL.AutoSize = true;
            this.passwordLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordLBL.Location = new System.Drawing.Point(27, 89);
            this.passwordLBL.Name = "passwordLBL";
            this.passwordLBL.Size = new System.Drawing.Size(82, 20);
            this.passwordLBL.TabIndex = 2;
            this.passwordLBL.Text = "Password:";
            this.passwordLBL.Click += new System.EventHandler(this.label1_Click);
            // 
            // usernameLBL
            // 
            this.usernameLBL.AutoSize = true;
            this.usernameLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernameLBL.Location = new System.Drawing.Point(27, 36);
            this.usernameLBL.Name = "usernameLBL";
            this.usernameLBL.Size = new System.Drawing.Size(87, 20);
            this.usernameLBL.TabIndex = 3;
            this.usernameLBL.Text = "Username:";
            this.usernameLBL.Click += new System.EventHandler(this.usernameTXT_Click);
            // 
            // loginBTN
            // 
            this.loginBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginBTN.Location = new System.Drawing.Point(172, 168);
            this.loginBTN.Name = "loginBTN";
            this.loginBTN.Size = new System.Drawing.Size(108, 60);
            this.loginBTN.TabIndex = 5;
            this.loginBTN.Text = "Login";
            this.loginBTN.UseVisualStyleBackColor = true;
            this.loginBTN.Click += new System.EventHandler(this.button1_Click);
            // 
            // Login_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(516, 311);
            this.Controls.Add(this.loginBTN);
            this.Controls.Add(this.usernameLBL);
            this.Controls.Add(this.passwordLBL);
            this.Controls.Add(this.passwordTXTBOX);
            this.Controls.Add(this.usernameTXTBOX);
            this.Name = "Login_Form";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox usernameTXTBOX;
        private System.Windows.Forms.TextBox passwordTXTBOX;
        private System.Windows.Forms.Label passwordLBL;
        private System.Windows.Forms.Label usernameLBL;
        private System.Windows.Forms.Button loginBTN;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentInformationSystem
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
        string Classes = "";
        private void saveBTN_Click(object sender, EventArgs e)
        {
            
            string classes = this.Classes;
            
            dataGridView.Rows.Add(Classes);
        }

        private void cs511BTN_CheckedChanged(object sender, EventArgs e)
        {
            Classes = "CS 511";
        }

        private void cs517BTN_CheckedChanged(object sender, EventArgs e)
        {
            Classes = "CS 517";
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void cs511Description_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Design & Analysis of Algorithm");
        }

        private void cs517Description_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Application of Statistical Methods");
        }

        private void cs521Description_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Object Oriented Program & Design");
        }

        private void cs531Description_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Computer Architecture");
        }

        private void cs582Description_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Wireless & Mobile Computing");
        }

        private void cs593Description_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Advance Topics in Computer Science");
        }

        private void deleteBTN_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView.CurrentCell.RowIndex;
            dataGridView.Rows.RemoveAt(rowIndex);
        }

        private void updateBTN_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView.CurrentCell.RowIndex;
            DataGridViewRow newDataRow = dataGridView.Rows[rowIndex];
            newDataRow.Cells[0].Value = this.Classes;
        }

        private void cs521BTN_CheckedChanged(object sender, EventArgs e)
        {
            Classes = "CS 521";
        }

        private void cs531BTN_CheckedChanged(object sender, EventArgs e)
        {
            Classes = "CS 531";
        }

        private void cs582BTN_CheckedChanged(object sender, EventArgs e)
        {
            Classes = "CS 582";
        }

        private void cs593BTN_CheckedChanged(object sender, EventArgs e)
        {
            Classes = "CS 593";
        }

        private void contactTXTBOX_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

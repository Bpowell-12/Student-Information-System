﻿namespace StudentInformationSystem
{
    partial class ClassForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InstructorNameTXTBOX = new System.Windows.Forms.TextBox();
            this.instructorIdTXTBOX = new System.Windows.Forms.TextBox();
            this.instSemTXTBOX = new System.Windows.Forms.TextBox();
            this.classDesTXTBOX = new System.Windows.Forms.TextBox();
            this.instCourseTXTBOX = new System.Windows.Forms.TextBox();
            this.instructorEmailTXTBOX = new System.Windows.Forms.TextBox();
            this.instructorNameLBL = new System.Windows.Forms.Label();
            this.instructorIdLBL = new System.Windows.Forms.Label();
            this.instructorEmailLBL = new System.Windows.Forms.Label();
            this.instructorSemesterLBL = new System.Windows.Forms.Label();
            this.instructorCourseLBL = new System.Windows.Forms.Label();
            this.instructorInputLBL = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // InstructorNameTXTBOX
            // 
            this.InstructorNameTXTBOX.Location = new System.Drawing.Point(275, 78);
            this.InstructorNameTXTBOX.Name = "InstructorNameTXTBOX";
            this.InstructorNameTXTBOX.Size = new System.Drawing.Size(197, 20);
            this.InstructorNameTXTBOX.TabIndex = 2;
            this.InstructorNameTXTBOX.Text = "Brandon Powell";
            // 
            // instructorIdTXTBOX
            // 
            this.instructorIdTXTBOX.Location = new System.Drawing.Point(275, 118);
            this.instructorIdTXTBOX.Name = "instructorIdTXTBOX";
            this.instructorIdTXTBOX.Size = new System.Drawing.Size(197, 20);
            this.instructorIdTXTBOX.TabIndex = 3;
            this.instructorIdTXTBOX.Text = "A00123456";
            // 
            // instSemTXTBOX
            // 
            this.instSemTXTBOX.Location = new System.Drawing.Point(275, 200);
            this.instSemTXTBOX.Name = "instSemTXTBOX";
            this.instSemTXTBOX.Size = new System.Drawing.Size(197, 20);
            this.instSemTXTBOX.TabIndex = 4;
            this.instSemTXTBOX.Text = "Fall";
            // 
            // classDesTXTBOX
            // 
            this.classDesTXTBOX.Location = new System.Drawing.Point(275, 286);
            this.classDesTXTBOX.MaxLength = 15;
            this.classDesTXTBOX.Multiline = true;
            this.classDesTXTBOX.Name = "classDesTXTBOX";
            this.classDesTXTBOX.Size = new System.Drawing.Size(392, 46);
            this.classDesTXTBOX.TabIndex = 5;
            this.classDesTXTBOX.Text = "This will be a class that will challenge students in the given programming langua" +
    "ges and also build their confidence that they will be able to take on in the car" +
    "eers.\r\n";
            // 
            // instCourseTXTBOX
            // 
            this.instCourseTXTBOX.Location = new System.Drawing.Point(275, 241);
            this.instCourseTXTBOX.Name = "instCourseTXTBOX";
            this.instCourseTXTBOX.Size = new System.Drawing.Size(197, 20);
            this.instCourseTXTBOX.TabIndex = 6;
            this.instCourseTXTBOX.Text = "CS 123";
            // 
            // instructorEmailTXTBOX
            // 
            this.instructorEmailTXTBOX.Location = new System.Drawing.Point(275, 162);
            this.instructorEmailTXTBOX.Name = "instructorEmailTXTBOX";
            this.instructorEmailTXTBOX.Size = new System.Drawing.Size(197, 20);
            this.instructorEmailTXTBOX.TabIndex = 7;
            this.instructorEmailTXTBOX.Text = "bulldogs@gmail.com";
            // 
            // instructorNameLBL
            // 
            this.instructorNameLBL.AutoSize = true;
            this.instructorNameLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructorNameLBL.Location = new System.Drawing.Point(160, 79);
            this.instructorNameLBL.Name = "instructorNameLBL";
            this.instructorNameLBL.Size = new System.Drawing.Size(114, 16);
            this.instructorNameLBL.TabIndex = 8;
            this.instructorNameLBL.Text = "Professor Name : ";
            // 
            // instructorIdLBL
            // 
            this.instructorIdLBL.AutoSize = true;
            this.instructorIdLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructorIdLBL.Location = new System.Drawing.Point(187, 122);
            this.instructorIdLBL.Name = "instructorIdLBL";
            this.instructorIdLBL.Size = new System.Drawing.Size(87, 16);
            this.instructorIdLBL.TabIndex = 9;
            this.instructorIdLBL.Text = "Professor ID :";
            // 
            // instructorEmailLBL
            // 
            this.instructorEmailLBL.AutoSize = true;
            this.instructorEmailLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructorEmailLBL.Location = new System.Drawing.Point(166, 162);
            this.instructorEmailLBL.Name = "instructorEmailLBL";
            this.instructorEmailLBL.Size = new System.Drawing.Size(108, 16);
            this.instructorEmailLBL.TabIndex = 10;
            this.instructorEmailLBL.Text = "Professor Email :";
            // 
            // instructorSemesterLBL
            // 
            this.instructorSemesterLBL.AutoSize = true;
            this.instructorSemesterLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructorSemesterLBL.Location = new System.Drawing.Point(198, 200);
            this.instructorSemesterLBL.Name = "instructorSemesterLBL";
            this.instructorSemesterLBL.Size = new System.Drawing.Size(71, 16);
            this.instructorSemesterLBL.TabIndex = 11;
            this.instructorSemesterLBL.Text = "Semester :";
            // 
            // instructorCourseLBL
            // 
            this.instructorCourseLBL.AutoSize = true;
            this.instructorCourseLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructorCourseLBL.Location = new System.Drawing.Point(197, 241);
            this.instructorCourseLBL.Name = "instructorCourseLBL";
            this.instructorCourseLBL.Size = new System.Drawing.Size(72, 16);
            this.instructorCourseLBL.TabIndex = 12;
            this.instructorCourseLBL.Text = "Course ID :";
            // 
            // instructorInputLBL
            // 
            this.instructorInputLBL.AutoSize = true;
            this.instructorInputLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructorInputLBL.Location = new System.Drawing.Point(148, 287);
            this.instructorInputLBL.Name = "instructorInputLBL";
            this.instructorInputLBL.Size = new System.Drawing.Size(121, 16);
            this.instructorInputLBL.TabIndex = 13;
            this.instructorInputLBL.Text = "Class Description : ";
            this.instructorInputLBL.Click += new System.EventHandler(this.label6_Click);
            // 
            // ClassForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.instructorInputLBL);
            this.Controls.Add(this.instructorCourseLBL);
            this.Controls.Add(this.instructorSemesterLBL);
            this.Controls.Add(this.instructorEmailLBL);
            this.Controls.Add(this.instructorIdLBL);
            this.Controls.Add(this.instructorNameLBL);
            this.Controls.Add(this.instructorEmailTXTBOX);
            this.Controls.Add(this.instCourseTXTBOX);
            this.Controls.Add(this.classDesTXTBOX);
            this.Controls.Add(this.instSemTXTBOX);
            this.Controls.Add(this.instructorIdTXTBOX);
            this.Controls.Add(this.InstructorNameTXTBOX);
            this.Name = "ClassForm";
            this.Text = "CS 123 Info";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox InstructorNameTXTBOX;
        private System.Windows.Forms.TextBox instructorIdTXTBOX;
        private System.Windows.Forms.TextBox instSemTXTBOX;
        private System.Windows.Forms.TextBox classDesTXTBOX;
        private System.Windows.Forms.TextBox instCourseTXTBOX;
        private System.Windows.Forms.TextBox instructorEmailTXTBOX;
        private System.Windows.Forms.Label instructorNameLBL;
        private System.Windows.Forms.Label instructorIdLBL;
        private System.Windows.Forms.Label instructorEmailLBL;
        private System.Windows.Forms.Label instructorSemesterLBL;
        private System.Windows.Forms.Label instructorCourseLBL;
        private System.Windows.Forms.Label instructorInputLBL;
    }
}
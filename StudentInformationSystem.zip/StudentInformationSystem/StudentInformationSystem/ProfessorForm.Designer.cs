﻿namespace StudentInformationSystem
{
    partial class ProfessorInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.profFirstLBL = new System.Windows.Forms.Label();
            this.proIdTXTBOX = new System.Windows.Forms.TextBox();
            this.proLnameTXTBOX = new System.Windows.Forms.TextBox();
            this.proFnameTXTBOX = new System.Windows.Forms.TextBox();
            this.proCourseIdTXTBOX = new System.Windows.Forms.TextBox();
            this.proEmailTXTBOX = new System.Windows.Forms.TextBox();
            this.profLstLBL = new System.Windows.Forms.Label();
            this.profIdLBL = new System.Windows.Forms.Label();
            this.proEmailLBL = new System.Windows.Forms.Label();
            this.proCourseLBL = new System.Windows.Forms.Label();
            this.contactLBL = new System.Windows.Forms.Label();
            this.contactTXTBOX = new System.Windows.Forms.TextBox();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.sIdLBL = new System.Windows.Forms.Label();
            this.sFnameLBL = new System.Windows.Forms.Label();
            this.sLnameLBL = new System.Windows.Forms.Label();
            this.pgLBL = new System.Windows.Forms.Label();
            this.midtermLBL = new System.Windows.Forms.Label();
            this.finalLBL = new System.Windows.Forms.Label();
            this.sIdTXTBOX = new System.Windows.Forms.TextBox();
            this.midtermTXTBOX = new System.Windows.Forms.TextBox();
            this.finalTXTBOX = new System.Windows.Forms.TextBox();
            this.sLnameTXTBOX = new System.Windows.Forms.TextBox();
            this.sFnameTXTBOX = new System.Windows.Forms.TextBox();
            this.pgTXTBOX = new System.Windows.Forms.TextBox();
            this.saveBTN = new System.Windows.Forms.Button();
            this.deleteBTN = new System.Windows.Forms.Button();
            this.updateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.Student_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pgrade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mgrade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fgrade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Average = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // profFirstLBL
            // 
            this.profFirstLBL.AutoSize = true;
            this.profFirstLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profFirstLBL.Location = new System.Drawing.Point(7, 18);
            this.profFirstLBL.Name = "profFirstLBL";
            this.profFirstLBL.Size = new System.Drawing.Size(139, 16);
            this.profFirstLBL.TabIndex = 1;
            this.profFirstLBL.Text = "Professor First Name :";
            this.profFirstLBL.Click += new System.EventHandler(this.profFirstLBL_Click);
            // 
            // proIdTXTBOX
            // 
            this.proIdTXTBOX.Location = new System.Drawing.Point(152, 68);
            this.proIdTXTBOX.Name = "proIdTXTBOX";
            this.proIdTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.proIdTXTBOX.TabIndex = 2;
            this.proIdTXTBOX.Text = "A00123456";
            // 
            // proLnameTXTBOX
            // 
            this.proLnameTXTBOX.Location = new System.Drawing.Point(152, 42);
            this.proLnameTXTBOX.Name = "proLnameTXTBOX";
            this.proLnameTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.proLnameTXTBOX.TabIndex = 3;
            this.proLnameTXTBOX.Text = "Powell";
            // 
            // proFnameTXTBOX
            // 
            this.proFnameTXTBOX.Location = new System.Drawing.Point(152, 17);
            this.proFnameTXTBOX.Name = "proFnameTXTBOX";
            this.proFnameTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.proFnameTXTBOX.TabIndex = 4;
            this.proFnameTXTBOX.Text = "Brandon";
            this.proFnameTXTBOX.TextChanged += new System.EventHandler(this.proFnameTXTBOX_TextChanged);
            // 
            // proCourseIdTXTBOX
            // 
            this.proCourseIdTXTBOX.Location = new System.Drawing.Point(152, 94);
            this.proCourseIdTXTBOX.Name = "proCourseIdTXTBOX";
            this.proCourseIdTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.proCourseIdTXTBOX.TabIndex = 7;
            this.proCourseIdTXTBOX.Text = "CS 123 ";
            // 
            // proEmailTXTBOX
            // 
            this.proEmailTXTBOX.Location = new System.Drawing.Point(416, 14);
            this.proEmailTXTBOX.Name = "proEmailTXTBOX";
            this.proEmailTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.proEmailTXTBOX.TabIndex = 8;
            this.proEmailTXTBOX.Text = "bulldogs@gmail.com";
            // 
            // profLstLBL
            // 
            this.profLstLBL.AutoSize = true;
            this.profLstLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profLstLBL.Location = new System.Drawing.Point(7, 42);
            this.profLstLBL.Name = "profLstLBL";
            this.profLstLBL.Size = new System.Drawing.Size(139, 16);
            this.profLstLBL.TabIndex = 10;
            this.profLstLBL.Text = "Professor Last Name :";
            // 
            // profIdLBL
            // 
            this.profIdLBL.AutoSize = true;
            this.profIdLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profIdLBL.Location = new System.Drawing.Point(59, 68);
            this.profIdLBL.Name = "profIdLBL";
            this.profIdLBL.Size = new System.Drawing.Size(87, 16);
            this.profIdLBL.TabIndex = 11;
            this.profIdLBL.Text = "Professor ID :";
            // 
            // proEmailLBL
            // 
            this.proEmailLBL.AutoSize = true;
            this.proEmailLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.proEmailLBL.Location = new System.Drawing.Point(360, 14);
            this.proEmailLBL.Name = "proEmailLBL";
            this.proEmailLBL.Size = new System.Drawing.Size(47, 16);
            this.proEmailLBL.TabIndex = 12;
            this.proEmailLBL.Text = "Email :";
            // 
            // proCourseLBL
            // 
            this.proCourseLBL.AutoSize = true;
            this.proCourseLBL.Location = new System.Drawing.Point(83, 97);
            this.proCourseLBL.Name = "proCourseLBL";
            this.proCourseLBL.Size = new System.Drawing.Size(60, 13);
            this.proCourseLBL.TabIndex = 13;
            this.proCourseLBL.Text = "Course ID :";
            // 
            // contactLBL
            // 
            this.contactLBL.AutoSize = true;
            this.contactLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactLBL.Location = new System.Drawing.Point(349, 40);
            this.contactLBL.Name = "contactLBL";
            this.contactLBL.Size = new System.Drawing.Size(58, 16);
            this.contactLBL.TabIndex = 14;
            this.contactLBL.Text = "Contact :";
            // 
            // contactTXTBOX
            // 
            this.contactTXTBOX.Location = new System.Drawing.Point(416, 40);
            this.contactTXTBOX.Name = "contactTXTBOX";
            this.contactTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.contactTXTBOX.TabIndex = 15;
            this.contactTXTBOX.Text = "(123) 444-8888";
            // 
            // dataGridView
            // 
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Student_ID,
            this.fName,
            this.Lname,
            this.Pgrade,
            this.Mgrade,
            this.Fgrade,
            this.Average});
            this.dataGridView.Location = new System.Drawing.Point(10, 245);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.Size = new System.Drawing.Size(728, 193);
            this.dataGridView.TabIndex = 16;
            this.dataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // sIdLBL
            // 
            this.sIdLBL.AutoSize = true;
            this.sIdLBL.Location = new System.Drawing.Point(107, 144);
            this.sIdLBL.Name = "sIdLBL";
            this.sIdLBL.Size = new System.Drawing.Size(61, 13);
            this.sIdLBL.TabIndex = 17;
            this.sIdLBL.Text = "Student ID:";
            // 
            // sFnameLBL
            // 
            this.sFnameLBL.AutoSize = true;
            this.sFnameLBL.Location = new System.Drawing.Point(69, 170);
            this.sFnameLBL.Name = "sFnameLBL";
            this.sFnameLBL.Size = new System.Drawing.Size(100, 13);
            this.sFnameLBL.TabIndex = 18;
            this.sFnameLBL.Text = "Student First Name:";
            // 
            // sLnameLBL
            // 
            this.sLnameLBL.AutoSize = true;
            this.sLnameLBL.Location = new System.Drawing.Point(68, 195);
            this.sLnameLBL.Name = "sLnameLBL";
            this.sLnameLBL.Size = new System.Drawing.Size(101, 13);
            this.sLnameLBL.TabIndex = 19;
            this.sLnameLBL.Text = "Student Last Name:";
            // 
            // pgLBL
            // 
            this.pgLBL.AutoSize = true;
            this.pgLBL.Location = new System.Drawing.Point(359, 140);
            this.pgLBL.Name = "pgLBL";
            this.pgLBL.Size = new System.Drawing.Size(75, 13);
            this.pgLBL.TabIndex = 20;
            this.pgLBL.Text = "Project Grade:";
            // 
            // midtermLBL
            // 
            this.midtermLBL.AutoSize = true;
            this.midtermLBL.Location = new System.Drawing.Point(352, 167);
            this.midtermLBL.Name = "midtermLBL";
            this.midtermLBL.Size = new System.Drawing.Size(82, 13);
            this.midtermLBL.TabIndex = 21;
            this.midtermLBL.Text = "Midterm Grade: ";
            // 
            // finalLBL
            // 
            this.finalLBL.AutoSize = true;
            this.finalLBL.Location = new System.Drawing.Point(370, 195);
            this.finalLBL.Name = "finalLBL";
            this.finalLBL.Size = new System.Drawing.Size(64, 13);
            this.finalLBL.TabIndex = 22;
            this.finalLBL.Text = "Final Grade:";
            // 
            // sIdTXTBOX
            // 
            this.sIdTXTBOX.Location = new System.Drawing.Point(174, 141);
            this.sIdTXTBOX.Name = "sIdTXTBOX";
            this.sIdTXTBOX.Size = new System.Drawing.Size(100, 20);
            this.sIdTXTBOX.TabIndex = 23;
            // 
            // midtermTXTBOX
            // 
            this.midtermTXTBOX.Location = new System.Drawing.Point(440, 163);
            this.midtermTXTBOX.Name = "midtermTXTBOX";
            this.midtermTXTBOX.Size = new System.Drawing.Size(100, 20);
            this.midtermTXTBOX.TabIndex = 24;
            // 
            // finalTXTBOX
            // 
            this.finalTXTBOX.Location = new System.Drawing.Point(440, 192);
            this.finalTXTBOX.Name = "finalTXTBOX";
            this.finalTXTBOX.Size = new System.Drawing.Size(100, 20);
            this.finalTXTBOX.TabIndex = 25;
            this.finalTXTBOX.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // sLnameTXTBOX
            // 
            this.sLnameTXTBOX.Location = new System.Drawing.Point(174, 192);
            this.sLnameTXTBOX.Name = "sLnameTXTBOX";
            this.sLnameTXTBOX.Size = new System.Drawing.Size(100, 20);
            this.sLnameTXTBOX.TabIndex = 26;
            // 
            // sFnameTXTBOX
            // 
            this.sFnameTXTBOX.Location = new System.Drawing.Point(174, 167);
            this.sFnameTXTBOX.Name = "sFnameTXTBOX";
            this.sFnameTXTBOX.Size = new System.Drawing.Size(100, 20);
            this.sFnameTXTBOX.TabIndex = 27;
            // 
            // pgTXTBOX
            // 
            this.pgTXTBOX.Location = new System.Drawing.Point(440, 137);
            this.pgTXTBOX.Name = "pgTXTBOX";
            this.pgTXTBOX.Size = new System.Drawing.Size(100, 20);
            this.pgTXTBOX.TabIndex = 28;
            // 
            // saveBTN
            // 
            this.saveBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBTN.Location = new System.Drawing.Point(663, 37);
            this.saveBTN.Name = "saveBTN";
            this.saveBTN.Size = new System.Drawing.Size(75, 23);
            this.saveBTN.TabIndex = 29;
            this.saveBTN.Text = "Save";
            this.saveBTN.UseVisualStyleBackColor = true;
            this.saveBTN.Click += new System.EventHandler(this.saveBTN_Click);
            // 
            // deleteBTN
            // 
            this.deleteBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBTN.Location = new System.Drawing.Point(663, 137);
            this.deleteBTN.Name = "deleteBTN";
            this.deleteBTN.Size = new System.Drawing.Size(75, 23);
            this.deleteBTN.TabIndex = 30;
            this.deleteBTN.Text = "Delete";
            this.deleteBTN.UseVisualStyleBackColor = true;
            this.deleteBTN.Click += new System.EventHandler(this.deleteBTN_Click);
            // 
            // updateBTN
            // 
            this.updateBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBTN.Location = new System.Drawing.Point(663, 87);
            this.updateBTN.Name = "updateBTN";
            this.updateBTN.Size = new System.Drawing.Size(75, 23);
            this.updateBTN.TabIndex = 31;
            this.updateBTN.Text = "Update";
            this.updateBTN.UseVisualStyleBackColor = true;
            this.updateBTN.Click += new System.EventHandler(this.updateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBTN.Location = new System.Drawing.Point(663, 185);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(75, 23);
            this.clearBTN.TabIndex = 32;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // Student_ID
            // 
            this.Student_ID.HeaderText = "Student ID";
            this.Student_ID.Name = "Student_ID";
            this.Student_ID.ReadOnly = true;
            // 
            // fName
            // 
            this.fName.HeaderText = "First Name";
            this.fName.Name = "fName";
            this.fName.ReadOnly = true;
            // 
            // Lname
            // 
            this.Lname.HeaderText = "Last Name ";
            this.Lname.Name = "Lname";
            this.Lname.ReadOnly = true;
            // 
            // Pgrade
            // 
            this.Pgrade.HeaderText = "Project Grade";
            this.Pgrade.Name = "Pgrade";
            this.Pgrade.ReadOnly = true;
            // 
            // Mgrade
            // 
            this.Mgrade.HeaderText = "Midterm ";
            this.Mgrade.Name = "Mgrade";
            this.Mgrade.ReadOnly = true;
            // 
            // Fgrade
            // 
            this.Fgrade.HeaderText = "Final";
            this.Fgrade.Name = "Fgrade";
            this.Fgrade.ReadOnly = true;
            // 
            // Average
            // 
            this.Average.HeaderText = "Average";
            this.Average.Name = "Average";
            this.Average.ReadOnly = true;
            // 
            // ProfessorInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 450);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.updateBTN);
            this.Controls.Add(this.deleteBTN);
            this.Controls.Add(this.saveBTN);
            this.Controls.Add(this.pgTXTBOX);
            this.Controls.Add(this.sFnameTXTBOX);
            this.Controls.Add(this.sLnameTXTBOX);
            this.Controls.Add(this.finalTXTBOX);
            this.Controls.Add(this.midtermTXTBOX);
            this.Controls.Add(this.sIdTXTBOX);
            this.Controls.Add(this.finalLBL);
            this.Controls.Add(this.midtermLBL);
            this.Controls.Add(this.pgLBL);
            this.Controls.Add(this.sLnameLBL);
            this.Controls.Add(this.sFnameLBL);
            this.Controls.Add(this.sIdLBL);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.contactTXTBOX);
            this.Controls.Add(this.contactLBL);
            this.Controls.Add(this.proCourseLBL);
            this.Controls.Add(this.proEmailLBL);
            this.Controls.Add(this.profIdLBL);
            this.Controls.Add(this.profLstLBL);
            this.Controls.Add(this.proEmailTXTBOX);
            this.Controls.Add(this.proCourseIdTXTBOX);
            this.Controls.Add(this.proFnameTXTBOX);
            this.Controls.Add(this.proLnameTXTBOX);
            this.Controls.Add(this.proIdTXTBOX);
            this.Controls.Add(this.profFirstLBL);
            this.Name = "ProfessorInfoForm";
            this.Text = "Professor Info";
            this.Load += new System.EventHandler(this.ProfessorInfoForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label profFirstLBL;
        private System.Windows.Forms.TextBox proIdTXTBOX;
        private System.Windows.Forms.TextBox proLnameTXTBOX;
        private System.Windows.Forms.TextBox proFnameTXTBOX;
        private System.Windows.Forms.TextBox proCourseIdTXTBOX;
        private System.Windows.Forms.TextBox proEmailTXTBOX;
        private System.Windows.Forms.Label profLstLBL;
        private System.Windows.Forms.Label profIdLBL;
        private System.Windows.Forms.Label proEmailLBL;
        private System.Windows.Forms.Label proCourseLBL;
        private System.Windows.Forms.Label contactLBL;
        private System.Windows.Forms.TextBox contactTXTBOX;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Label sIdLBL;
        private System.Windows.Forms.Label sFnameLBL;
        private System.Windows.Forms.Label sLnameLBL;
        private System.Windows.Forms.Label pgLBL;
        private System.Windows.Forms.Label midtermLBL;
        private System.Windows.Forms.Label finalLBL;
        private System.Windows.Forms.TextBox sIdTXTBOX;
        private System.Windows.Forms.TextBox midtermTXTBOX;
        private System.Windows.Forms.TextBox finalTXTBOX;
        private System.Windows.Forms.TextBox sLnameTXTBOX;
        private System.Windows.Forms.TextBox sFnameTXTBOX;
        private System.Windows.Forms.TextBox pgTXTBOX;
        private System.Windows.Forms.Button saveBTN;
        private System.Windows.Forms.Button deleteBTN;
        private System.Windows.Forms.Button updateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.DataGridViewTextBoxColumn Student_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn fName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pgrade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mgrade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fgrade;
        private System.Windows.Forms.DataGridViewTextBoxColumn Average;
    }
}
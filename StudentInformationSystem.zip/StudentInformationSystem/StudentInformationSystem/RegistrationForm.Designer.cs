﻿namespace StudentInformationSystem
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.updateBTN = new System.Windows.Forms.Button();
            this.deleteBTN = new System.Windows.Forms.Button();
            this.saveBTN = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.contactTXTBOX = new System.Windows.Forms.TextBox();
            this.contactLBL = new System.Windows.Forms.Label();
            this.proEmailLBL = new System.Windows.Forms.Label();
            this.IdLBL = new System.Windows.Forms.Label();
            this.LastLBL = new System.Windows.Forms.Label();
            this.EmailTXTBOX = new System.Windows.Forms.TextBox();
            this.FnameTXTBOX = new System.Windows.Forms.TextBox();
            this.LnameTXTBOX = new System.Windows.Forms.TextBox();
            this.IdTXTBOX = new System.Windows.Forms.TextBox();
            this.FirstLBL = new System.Windows.Forms.Label();
            this.cs511BTN = new System.Windows.Forms.RadioButton();
            this.cs517BTN = new System.Windows.Forms.RadioButton();
            this.cs521BTN = new System.Windows.Forms.RadioButton();
            this.cs531BTN = new System.Windows.Forms.RadioButton();
            this.cs582BTN = new System.Windows.Forms.RadioButton();
            this.cs593BTN = new System.Windows.Forms.RadioButton();
            this.cs511Description = new System.Windows.Forms.LinkLabel();
            this.cs517Description = new System.Windows.Forms.LinkLabel();
            this.cs521Description = new System.Windows.Forms.LinkLabel();
            this.cs531Description = new System.Windows.Forms.LinkLabel();
            this.cs582Description = new System.Windows.Forms.LinkLabel();
            this.cs593Description = new System.Windows.Forms.LinkLabel();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classesLBL = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // updateBTN
            // 
            this.updateBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBTN.Location = new System.Drawing.Point(691, 86);
            this.updateBTN.Name = "updateBTN";
            this.updateBTN.Size = new System.Drawing.Size(75, 23);
            this.updateBTN.TabIndex = 60;
            this.updateBTN.Text = "Update";
            this.updateBTN.UseVisualStyleBackColor = true;
            this.updateBTN.Click += new System.EventHandler(this.updateBTN_Click);
            // 
            // deleteBTN
            // 
            this.deleteBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBTN.Location = new System.Drawing.Point(691, 136);
            this.deleteBTN.Name = "deleteBTN";
            this.deleteBTN.Size = new System.Drawing.Size(75, 23);
            this.deleteBTN.TabIndex = 59;
            this.deleteBTN.Text = "Delete";
            this.deleteBTN.UseVisualStyleBackColor = true;
            this.deleteBTN.Click += new System.EventHandler(this.deleteBTN_Click);
            // 
            // saveBTN
            // 
            this.saveBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBTN.Location = new System.Drawing.Point(691, 36);
            this.saveBTN.Name = "saveBTN";
            this.saveBTN.Size = new System.Drawing.Size(75, 23);
            this.saveBTN.TabIndex = 58;
            this.saveBTN.Text = "Save";
            this.saveBTN.UseVisualStyleBackColor = true;
            this.saveBTN.Click += new System.EventHandler(this.saveBTN_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dataGridView.Location = new System.Drawing.Point(138, 245);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.Size = new System.Drawing.Size(430, 193);
            this.dataGridView.TabIndex = 45;
            this.dataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellContentClick);
            // 
            // contactTXTBOX
            // 
            this.contactTXTBOX.Location = new System.Drawing.Point(444, 39);
            this.contactTXTBOX.Name = "contactTXTBOX";
            this.contactTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.contactTXTBOX.TabIndex = 44;
            this.contactTXTBOX.Text = "(321) 555-9999";
            this.contactTXTBOX.TextChanged += new System.EventHandler(this.contactTXTBOX_TextChanged);
            // 
            // contactLBL
            // 
            this.contactLBL.AutoSize = true;
            this.contactLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactLBL.Location = new System.Drawing.Point(377, 39);
            this.contactLBL.Name = "contactLBL";
            this.contactLBL.Size = new System.Drawing.Size(58, 16);
            this.contactLBL.TabIndex = 43;
            this.contactLBL.Text = "Contact :";
            // 
            // proEmailLBL
            // 
            this.proEmailLBL.AutoSize = true;
            this.proEmailLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.proEmailLBL.Location = new System.Drawing.Point(388, 13);
            this.proEmailLBL.Name = "proEmailLBL";
            this.proEmailLBL.Size = new System.Drawing.Size(47, 16);
            this.proEmailLBL.TabIndex = 41;
            this.proEmailLBL.Text = "Email :";
            // 
            // IdLBL
            // 
            this.IdLBL.AutoSize = true;
            this.IdLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdLBL.Location = new System.Drawing.Point(135, 67);
            this.IdLBL.Name = "IdLBL";
            this.IdLBL.Size = new System.Drawing.Size(26, 16);
            this.IdLBL.TabIndex = 40;
            this.IdLBL.Text = "ID :";
            // 
            // LastLBL
            // 
            this.LastLBL.AutoSize = true;
            this.LastLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastLBL.Location = new System.Drawing.Point(83, 41);
            this.LastLBL.Name = "LastLBL";
            this.LastLBL.Size = new System.Drawing.Size(78, 16);
            this.LastLBL.TabIndex = 39;
            this.LastLBL.Text = "Last Name :";
            // 
            // EmailTXTBOX
            // 
            this.EmailTXTBOX.Location = new System.Drawing.Point(444, 13);
            this.EmailTXTBOX.Name = "EmailTXTBOX";
            this.EmailTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.EmailTXTBOX.TabIndex = 38;
            this.EmailTXTBOX.Text = "aamu@bulldogs.com";
            // 
            // FnameTXTBOX
            // 
            this.FnameTXTBOX.Location = new System.Drawing.Point(180, 16);
            this.FnameTXTBOX.Name = "FnameTXTBOX";
            this.FnameTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.FnameTXTBOX.TabIndex = 36;
            this.FnameTXTBOX.Text = "William";
            // 
            // LnameTXTBOX
            // 
            this.LnameTXTBOX.Location = new System.Drawing.Point(180, 41);
            this.LnameTXTBOX.Name = "LnameTXTBOX";
            this.LnameTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.LnameTXTBOX.TabIndex = 35;
            this.LnameTXTBOX.Text = "Powell";
            // 
            // IdTXTBOX
            // 
            this.IdTXTBOX.Location = new System.Drawing.Point(180, 67);
            this.IdTXTBOX.Name = "IdTXTBOX";
            this.IdTXTBOX.Size = new System.Drawing.Size(159, 20);
            this.IdTXTBOX.TabIndex = 34;
            this.IdTXTBOX.Text = "A00678901";
            // 
            // FirstLBL
            // 
            this.FirstLBL.AutoSize = true;
            this.FirstLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstLBL.Location = new System.Drawing.Point(35, 17);
            this.FirstLBL.Name = "FirstLBL";
            this.FirstLBL.Size = new System.Drawing.Size(126, 16);
            this.FirstLBL.TabIndex = 33;
            this.FirstLBL.Text = "Student First Name :";
            // 
            // cs511BTN
            // 
            this.cs511BTN.AutoSize = true;
            this.cs511BTN.Location = new System.Drawing.Point(138, 142);
            this.cs511BTN.Name = "cs511BTN";
            this.cs511BTN.Size = new System.Drawing.Size(60, 17);
            this.cs511BTN.TabIndex = 62;
            this.cs511BTN.TabStop = true;
            this.cs511BTN.Text = "CS 511";
            this.cs511BTN.UseVisualStyleBackColor = true;
            this.cs511BTN.CheckedChanged += new System.EventHandler(this.cs511BTN_CheckedChanged);
            // 
            // cs517BTN
            // 
            this.cs517BTN.AutoSize = true;
            this.cs517BTN.Location = new System.Drawing.Point(138, 167);
            this.cs517BTN.Name = "cs517BTN";
            this.cs517BTN.Size = new System.Drawing.Size(60, 17);
            this.cs517BTN.TabIndex = 63;
            this.cs517BTN.TabStop = true;
            this.cs517BTN.Text = "CS 517";
            this.cs517BTN.UseVisualStyleBackColor = true;
            this.cs517BTN.CheckedChanged += new System.EventHandler(this.cs517BTN_CheckedChanged);
            // 
            // cs521BTN
            // 
            this.cs521BTN.AutoSize = true;
            this.cs521BTN.Location = new System.Drawing.Point(138, 190);
            this.cs521BTN.Name = "cs521BTN";
            this.cs521BTN.Size = new System.Drawing.Size(60, 17);
            this.cs521BTN.TabIndex = 64;
            this.cs521BTN.TabStop = true;
            this.cs521BTN.Text = "CS 521";
            this.cs521BTN.UseVisualStyleBackColor = true;
            this.cs521BTN.CheckedChanged += new System.EventHandler(this.cs521BTN_CheckedChanged);
            // 
            // cs531BTN
            // 
            this.cs531BTN.AutoSize = true;
            this.cs531BTN.Location = new System.Drawing.Point(423, 144);
            this.cs531BTN.Name = "cs531BTN";
            this.cs531BTN.Size = new System.Drawing.Size(60, 17);
            this.cs531BTN.TabIndex = 65;
            this.cs531BTN.TabStop = true;
            this.cs531BTN.Text = "CS 531";
            this.cs531BTN.UseVisualStyleBackColor = true;
            this.cs531BTN.CheckedChanged += new System.EventHandler(this.cs531BTN_CheckedChanged);
            // 
            // cs582BTN
            // 
            this.cs582BTN.AutoSize = true;
            this.cs582BTN.Location = new System.Drawing.Point(423, 167);
            this.cs582BTN.Name = "cs582BTN";
            this.cs582BTN.Size = new System.Drawing.Size(60, 17);
            this.cs582BTN.TabIndex = 66;
            this.cs582BTN.TabStop = true;
            this.cs582BTN.Text = "CS 582";
            this.cs582BTN.UseVisualStyleBackColor = true;
            this.cs582BTN.CheckedChanged += new System.EventHandler(this.cs582BTN_CheckedChanged);
            // 
            // cs593BTN
            // 
            this.cs593BTN.AutoSize = true;
            this.cs593BTN.Location = new System.Drawing.Point(423, 190);
            this.cs593BTN.Name = "cs593BTN";
            this.cs593BTN.Size = new System.Drawing.Size(60, 17);
            this.cs593BTN.TabIndex = 67;
            this.cs593BTN.TabStop = true;
            this.cs593BTN.Text = "CS 593";
            this.cs593BTN.UseVisualStyleBackColor = true;
            this.cs593BTN.CheckedChanged += new System.EventHandler(this.cs593BTN_CheckedChanged);
            // 
            // cs511Description
            // 
            this.cs511Description.AutoSize = true;
            this.cs511Description.Location = new System.Drawing.Point(204, 144);
            this.cs511Description.Name = "cs511Description";
            this.cs511Description.Size = new System.Drawing.Size(60, 13);
            this.cs511Description.TabIndex = 68;
            this.cs511Description.TabStop = true;
            this.cs511Description.Text = "Description";
            this.cs511Description.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.cs511Description_LinkClicked);
            // 
            // cs517Description
            // 
            this.cs517Description.AutoSize = true;
            this.cs517Description.Location = new System.Drawing.Point(204, 169);
            this.cs517Description.Name = "cs517Description";
            this.cs517Description.Size = new System.Drawing.Size(60, 13);
            this.cs517Description.TabIndex = 69;
            this.cs517Description.TabStop = true;
            this.cs517Description.Text = "Description";
            this.cs517Description.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.cs517Description_LinkClicked);
            // 
            // cs521Description
            // 
            this.cs521Description.AutoSize = true;
            this.cs521Description.Location = new System.Drawing.Point(204, 192);
            this.cs521Description.Name = "cs521Description";
            this.cs521Description.Size = new System.Drawing.Size(60, 13);
            this.cs521Description.TabIndex = 70;
            this.cs521Description.TabStop = true;
            this.cs521Description.Text = "Description";
            this.cs521Description.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.cs521Description_LinkClicked);
            // 
            // cs531Description
            // 
            this.cs531Description.AutoSize = true;
            this.cs531Description.Location = new System.Drawing.Point(489, 146);
            this.cs531Description.Name = "cs531Description";
            this.cs531Description.Size = new System.Drawing.Size(60, 13);
            this.cs531Description.TabIndex = 71;
            this.cs531Description.TabStop = true;
            this.cs531Description.Text = "Description";
            this.cs531Description.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.cs531Description_LinkClicked);
            // 
            // cs582Description
            // 
            this.cs582Description.AutoSize = true;
            this.cs582Description.Location = new System.Drawing.Point(489, 169);
            this.cs582Description.Name = "cs582Description";
            this.cs582Description.Size = new System.Drawing.Size(60, 13);
            this.cs582Description.TabIndex = 72;
            this.cs582Description.TabStop = true;
            this.cs582Description.Text = "Description";
            this.cs582Description.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.cs582Description_LinkClicked);
            // 
            // cs593Description
            // 
            this.cs593Description.AutoSize = true;
            this.cs593Description.Location = new System.Drawing.Point(489, 192);
            this.cs593Description.Name = "cs593Description";
            this.cs593Description.Size = new System.Drawing.Size(60, 13);
            this.cs593Description.TabIndex = 73;
            this.cs593Description.TabStop = true;
            this.cs593Description.Text = "Description";
            this.cs593Description.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.cs593Description_LinkClicked);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Classes";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // classesLBL
            // 
            this.classesLBL.AutoSize = true;
            this.classesLBL.Location = new System.Drawing.Point(38, 145);
            this.classesLBL.Name = "classesLBL";
            this.classesLBL.Size = new System.Drawing.Size(49, 13);
            this.classesLBL.TabIndex = 74;
            this.classesLBL.Text = "Classes :";
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.classesLBL);
            this.Controls.Add(this.cs593Description);
            this.Controls.Add(this.cs582Description);
            this.Controls.Add(this.cs531Description);
            this.Controls.Add(this.cs521Description);
            this.Controls.Add(this.cs517Description);
            this.Controls.Add(this.cs511Description);
            this.Controls.Add(this.cs593BTN);
            this.Controls.Add(this.cs582BTN);
            this.Controls.Add(this.cs531BTN);
            this.Controls.Add(this.cs521BTN);
            this.Controls.Add(this.cs517BTN);
            this.Controls.Add(this.cs511BTN);
            this.Controls.Add(this.updateBTN);
            this.Controls.Add(this.deleteBTN);
            this.Controls.Add(this.saveBTN);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.contactTXTBOX);
            this.Controls.Add(this.contactLBL);
            this.Controls.Add(this.proEmailLBL);
            this.Controls.Add(this.IdLBL);
            this.Controls.Add(this.LastLBL);
            this.Controls.Add(this.EmailTXTBOX);
            this.Controls.Add(this.FnameTXTBOX);
            this.Controls.Add(this.LnameTXTBOX);
            this.Controls.Add(this.IdTXTBOX);
            this.Controls.Add(this.FirstLBL);
            this.Name = "RegistrationForm";
            this.Text = "Registration";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button updateBTN;
        private System.Windows.Forms.Button deleteBTN;
        private System.Windows.Forms.Button saveBTN;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.TextBox contactTXTBOX;
        private System.Windows.Forms.Label contactLBL;
        private System.Windows.Forms.Label proEmailLBL;
        private System.Windows.Forms.Label IdLBL;
        private System.Windows.Forms.Label LastLBL;
        private System.Windows.Forms.TextBox EmailTXTBOX;
        private System.Windows.Forms.TextBox FnameTXTBOX;
        private System.Windows.Forms.TextBox LnameTXTBOX;
        private System.Windows.Forms.TextBox IdTXTBOX;
        private System.Windows.Forms.Label FirstLBL;
        private System.Windows.Forms.RadioButton cs511BTN;
        private System.Windows.Forms.RadioButton cs517BTN;
        private System.Windows.Forms.RadioButton cs521BTN;
        private System.Windows.Forms.RadioButton cs531BTN;
        private System.Windows.Forms.RadioButton cs582BTN;
        private System.Windows.Forms.RadioButton cs593BTN;
        private System.Windows.Forms.LinkLabel cs511Description;
        private System.Windows.Forms.LinkLabel cs517Description;
        private System.Windows.Forms.LinkLabel cs521Description;
        private System.Windows.Forms.LinkLabel cs531Description;
        private System.Windows.Forms.LinkLabel cs582Description;
        private System.Windows.Forms.LinkLabel cs593Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Label classesLBL;
    }
}
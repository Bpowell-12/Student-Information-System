﻿namespace StudentInformationSystem
{
    partial class StudentInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gradeBTN = new System.Windows.Forms.Button();
            this.stu1stnameLBL = new System.Windows.Forms.Label();
            this.stuLstnameLBL = new System.Windows.Forms.Label();
            this.stuIDLBL = new System.Windows.Forms.Label();
            this.stuEmailLBL = new System.Windows.Forms.Label();
            this.stuAddressLBL = new System.Windows.Forms.Label();
            this.stuSemesterLBL = new System.Windows.Forms.Label();
            this.stuFNTXTBOX = new System.Windows.Forms.TextBox();
            this.stuSemTXTBOX = new System.Windows.Forms.TextBox();
            this.stuAddTXTBOX = new System.Windows.Forms.TextBox();
            this.stuEmailTXTBOX = new System.Windows.Forms.TextBox();
            this.stuIDTXTBOX = new System.Windows.Forms.TextBox();
            this.stuLNTXTBOX = new System.Windows.Forms.TextBox();
            this.registrationBTN = new System.Windows.Forms.Button();
            this.contactTXTBOX = new System.Windows.Forms.TextBox();
            this.contactLBL = new System.Windows.Forms.Label();
            this.classInfoBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // gradeBTN
            // 
            this.gradeBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gradeBTN.Location = new System.Drawing.Point(112, 276);
            this.gradeBTN.Name = "gradeBTN";
            this.gradeBTN.Size = new System.Drawing.Size(75, 36);
            this.gradeBTN.TabIndex = 0;
            this.gradeBTN.Text = "Grades";
            this.gradeBTN.UseVisualStyleBackColor = true;
            this.gradeBTN.Click += new System.EventHandler(this.gradeBTN_Click);
            // 
            // stu1stnameLBL
            // 
            this.stu1stnameLBL.AutoSize = true;
            this.stu1stnameLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stu1stnameLBL.Location = new System.Drawing.Point(64, 20);
            this.stu1stnameLBL.Name = "stu1stnameLBL";
            this.stu1stnameLBL.Size = new System.Drawing.Size(126, 16);
            this.stu1stnameLBL.TabIndex = 2;
            this.stu1stnameLBL.Text = "Student First Name :";
            // 
            // stuLstnameLBL
            // 
            this.stuLstnameLBL.AutoSize = true;
            this.stuLstnameLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stuLstnameLBL.Location = new System.Drawing.Point(64, 58);
            this.stuLstnameLBL.Name = "stuLstnameLBL";
            this.stuLstnameLBL.Size = new System.Drawing.Size(126, 16);
            this.stuLstnameLBL.TabIndex = 3;
            this.stuLstnameLBL.Text = "Student Last Name :";
            // 
            // stuIDLBL
            // 
            this.stuIDLBL.AutoSize = true;
            this.stuIDLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stuIDLBL.Location = new System.Drawing.Point(109, 98);
            this.stuIDLBL.Name = "stuIDLBL";
            this.stuIDLBL.Size = new System.Drawing.Size(81, 16);
            this.stuIDLBL.TabIndex = 4;
            this.stuIDLBL.Text = "Students ID :";
            // 
            // stuEmailLBL
            // 
            this.stuEmailLBL.AutoSize = true;
            this.stuEmailLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stuEmailLBL.Location = new System.Drawing.Point(89, 130);
            this.stuEmailLBL.Name = "stuEmailLBL";
            this.stuEmailLBL.Size = new System.Drawing.Size(102, 16);
            this.stuEmailLBL.TabIndex = 5;
            this.stuEmailLBL.Text = "Students Email :";
            // 
            // stuAddressLBL
            // 
            this.stuAddressLBL.AutoSize = true;
            this.stuAddressLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stuAddressLBL.Location = new System.Drawing.Point(126, 182);
            this.stuAddressLBL.Name = "stuAddressLBL";
            this.stuAddressLBL.Size = new System.Drawing.Size(64, 16);
            this.stuAddressLBL.TabIndex = 6;
            this.stuAddressLBL.Text = "Address :";
            // 
            // stuSemesterLBL
            // 
            this.stuSemesterLBL.AutoSize = true;
            this.stuSemesterLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stuSemesterLBL.Location = new System.Drawing.Point(119, 216);
            this.stuSemesterLBL.Name = "stuSemesterLBL";
            this.stuSemesterLBL.Size = new System.Drawing.Size(71, 16);
            this.stuSemesterLBL.TabIndex = 7;
            this.stuSemesterLBL.Text = "Semester :";
            this.stuSemesterLBL.Click += new System.EventHandler(this.label6_Click);
            // 
            // stuFNTXTBOX
            // 
            this.stuFNTXTBOX.Location = new System.Drawing.Point(196, 16);
            this.stuFNTXTBOX.Name = "stuFNTXTBOX";
            this.stuFNTXTBOX.Size = new System.Drawing.Size(189, 20);
            this.stuFNTXTBOX.TabIndex = 8;
            this.stuFNTXTBOX.Text = "William ";
            // 
            // stuSemTXTBOX
            // 
            this.stuSemTXTBOX.Location = new System.Drawing.Point(196, 216);
            this.stuSemTXTBOX.Name = "stuSemTXTBOX";
            this.stuSemTXTBOX.Size = new System.Drawing.Size(189, 20);
            this.stuSemTXTBOX.TabIndex = 10;
            this.stuSemTXTBOX.Text = "Fall";
            this.stuSemTXTBOX.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // stuAddTXTBOX
            // 
            this.stuAddTXTBOX.Location = new System.Drawing.Point(196, 182);
            this.stuAddTXTBOX.Name = "stuAddTXTBOX";
            this.stuAddTXTBOX.Size = new System.Drawing.Size(189, 20);
            this.stuAddTXTBOX.TabIndex = 11;
            this.stuAddTXTBOX.Tag = "";
            this.stuAddTXTBOX.Text = "123 aamu blvd";
            this.stuAddTXTBOX.TextChanged += new System.EventHandler(this.stuAddTXTBOX_TextChanged);
            // 
            // stuEmailTXTBOX
            // 
            this.stuEmailTXTBOX.Location = new System.Drawing.Point(196, 130);
            this.stuEmailTXTBOX.Name = "stuEmailTXTBOX";
            this.stuEmailTXTBOX.Size = new System.Drawing.Size(189, 20);
            this.stuEmailTXTBOX.TabIndex = 12;
            this.stuEmailTXTBOX.Text = "aamu@bulldogs.com";
            // 
            // stuIDTXTBOX
            // 
            this.stuIDTXTBOX.Location = new System.Drawing.Point(196, 98);
            this.stuIDTXTBOX.Name = "stuIDTXTBOX";
            this.stuIDTXTBOX.Size = new System.Drawing.Size(189, 20);
            this.stuIDTXTBOX.TabIndex = 13;
            this.stuIDTXTBOX.Text = "A00678901";
            // 
            // stuLNTXTBOX
            // 
            this.stuLNTXTBOX.Location = new System.Drawing.Point(196, 58);
            this.stuLNTXTBOX.Name = "stuLNTXTBOX";
            this.stuLNTXTBOX.Size = new System.Drawing.Size(189, 20);
            this.stuLNTXTBOX.TabIndex = 14;
            this.stuLNTXTBOX.Text = "Powell";
            // 
            // registrationBTN
            // 
            this.registrationBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registrationBTN.Location = new System.Drawing.Point(322, 276);
            this.registrationBTN.Name = "registrationBTN";
            this.registrationBTN.Size = new System.Drawing.Size(185, 36);
            this.registrationBTN.TabIndex = 15;
            this.registrationBTN.Text = "Register for Spring Classes";
            this.registrationBTN.UseVisualStyleBackColor = true;
            this.registrationBTN.Click += new System.EventHandler(this.registrationBTN_Click);
            // 
            // contactTXTBOX
            // 
            this.contactTXTBOX.Location = new System.Drawing.Point(196, 156);
            this.contactTXTBOX.Name = "contactTXTBOX";
            this.contactTXTBOX.Size = new System.Drawing.Size(189, 20);
            this.contactTXTBOX.TabIndex = 46;
            this.contactTXTBOX.Text = "(321) 555-9999";
            // 
            // contactLBL
            // 
            this.contactLBL.AutoSize = true;
            this.contactLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactLBL.Location = new System.Drawing.Point(129, 156);
            this.contactLBL.Name = "contactLBL";
            this.contactLBL.Size = new System.Drawing.Size(58, 16);
            this.contactLBL.TabIndex = 45;
            this.contactLBL.Text = "Contact :";
            // 
            // classInfoBTN
            // 
            this.classInfoBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classInfoBTN.Location = new System.Drawing.Point(221, 276);
            this.classInfoBTN.Name = "classInfoBTN";
            this.classInfoBTN.Size = new System.Drawing.Size(75, 36);
            this.classInfoBTN.TabIndex = 47;
            this.classInfoBTN.Text = "Class Info";
            this.classInfoBTN.UseVisualStyleBackColor = true;
            this.classInfoBTN.Click += new System.EventHandler(this.classInfoBTN_Click);
            // 
            // StudentInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 357);
            this.Controls.Add(this.classInfoBTN);
            this.Controls.Add(this.contactTXTBOX);
            this.Controls.Add(this.contactLBL);
            this.Controls.Add(this.registrationBTN);
            this.Controls.Add(this.stuLNTXTBOX);
            this.Controls.Add(this.stuIDTXTBOX);
            this.Controls.Add(this.stuEmailTXTBOX);
            this.Controls.Add(this.stuAddTXTBOX);
            this.Controls.Add(this.stuSemTXTBOX);
            this.Controls.Add(this.stuFNTXTBOX);
            this.Controls.Add(this.stuSemesterLBL);
            this.Controls.Add(this.stuAddressLBL);
            this.Controls.Add(this.stuEmailLBL);
            this.Controls.Add(this.stuIDLBL);
            this.Controls.Add(this.stuLstnameLBL);
            this.Controls.Add(this.stu1stnameLBL);
            this.Controls.Add(this.gradeBTN);
            this.Name = "StudentInfoForm";
            this.Text = "Student Info";
            this.Load += new System.EventHandler(this.StudentInfoForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button gradeBTN;
        private System.Windows.Forms.Label stu1stnameLBL;
        private System.Windows.Forms.Label stuLstnameLBL;
        private System.Windows.Forms.Label stuIDLBL;
        private System.Windows.Forms.Label stuEmailLBL;
        private System.Windows.Forms.Label stuAddressLBL;
        private System.Windows.Forms.Label stuSemesterLBL;
        private System.Windows.Forms.TextBox stuFNTXTBOX;
        private System.Windows.Forms.TextBox stuSemTXTBOX;
        private System.Windows.Forms.TextBox stuAddTXTBOX;
        private System.Windows.Forms.TextBox stuEmailTXTBOX;
        private System.Windows.Forms.TextBox stuIDTXTBOX;
        private System.Windows.Forms.TextBox stuLNTXTBOX;
        private System.Windows.Forms.Button registrationBTN;
        private System.Windows.Forms.TextBox contactTXTBOX;
        private System.Windows.Forms.Label contactLBL;
        private System.Windows.Forms.Button classInfoBTN;
    }
}
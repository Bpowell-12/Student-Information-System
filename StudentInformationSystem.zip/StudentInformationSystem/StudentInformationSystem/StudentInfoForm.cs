﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentInformationSystem
{
    public partial class StudentInfoForm : Form
    {
        public StudentInfoForm()
        {
            InitializeComponent();
        }

        private void StudentInfoForm_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void stuInfoBTN_Click(object sender, EventArgs e)
        {

        }

        private void stuAddTXTBOX_TextChanged(object sender, EventArgs e)
        {

        }

        private void registrationBTN_Click(object sender, EventArgs e)
        {
            //this.Hide();
            RegistrationForm f2 = new RegistrationForm();
            f2.Show();
        }

        private void gradeBTN_Click(object sender, EventArgs e)
        {
            GradesForm f2 = new GradesForm();
            f2.Show();
        }

        private void classInfoBTN_Click(object sender, EventArgs e)
        {
            ClassForm f2= new ClassForm();
            f2.Show();
        }
    }
}

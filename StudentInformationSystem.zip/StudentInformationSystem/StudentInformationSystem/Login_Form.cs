﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentInformationSystem
{
    public partial class Login_Form : Form
    {
        public Login_Form()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(usernameTXTBOX.Text == "Student" && passwordTXTBOX.Text == "Student")
            {
                
                //this.Hide();
                StudentInfoForm f2 = new StudentInfoForm();
                f2.Show();


            }

            else if(usernameTXTBOX.Text == "Professor" && passwordTXTBOX.Text == "Professor")
            {
                
                //this.Hide();
                ProfessorInfoForm f2 = new ProfessorInfoForm();
                f2.Show();
            }


            else
            {
                MessageBox.Show("Invalid Login!");
            }
        }

        private void usernameTXT_Click(object sender, EventArgs e)
        {

        }

        
    }
}
